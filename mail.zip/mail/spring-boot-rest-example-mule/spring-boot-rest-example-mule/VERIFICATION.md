# 実行確認結果（2026-10-29 / Windows）

使用環境: Mule Enterprise Runtime 4.13.0、Temurin JDK 17.0.20.1+1、Temurin JDK 8u504、Maven 3.9.16。

## 結果

| 確認 | 結果 |
| --- | --- |
| 元の Java ソース / POM の `git diff --exit-code` | 差分なし。元フォルダーは変更していない。 |
| 実際の JDK 8 で通常 JAR を作成 | 成功。`HotelController.class` の major version = 52。 |
| 元の `HotelControllerTest` | 2 件成功、失敗・エラー 0。 |
| 元の依存関係 / オプションなしで JDK 17 起動 | 失敗。Spring CGLIB の `InaccessibleObjectException`。 |
| 単独 JDK 17 で `--add-opens` を追加 | Spring アプリ起動に成功。 |
| Mule に追加 `--add-opens` だけを指定 | アプリ起動前に JPMS オプション検証で拒否。 |
| Mule 同一 JVM / JDK 17 の開発限定試験 | JSON / XML を含む HTTP 確認 13 件すべて成功。Swagger 仕様 / UI も HTTP 200。 |
| Mule JDK 17 + JDK 8 子プロセス | 同じ HTTP 確認 13 件すべて成功。Swagger 仕様も HTTP 200。 |
| JDK 8 子プロセス方式の Mule JVM 引数 | 追加の `java.lang=ALL-UNNAMED` なし、`mule.module.tweaking.validation.skip` なし。 |
| API Manager 有効プロファイル | パッケージ作成成功。Autodiscovery と `flowRef="hotel-api-main"`、API ID の格納を確認。 |
| API ID 未指定で管理用ビルド | Maven Enforcer が拒否することを確認。 |
| API Manager 実アカウントへの接続・ポリシー実行 | 未確認。実際の API インスタンス ID / 環境資格情報が未提供。 |

管理用パッケージのビルド確認には検証値 `123456` を使用し、API Manager への接続やデプロイはしていません。配備には自身の実際の API Instance ID でビルドし直してください。最後に残すパッケージはローカル確認用（API Manager 無効）です。

## HTTP で確認した内容（各方式とも同じ 13 件）

1. JSON POST → 201 と公開側を指す Location。
2. GET → 200、作成した属性の一致。
3. GET `?page=0&size=1` → 200、ページング指定の反映。
4. PUT（URL と本文の ID が一致）→ 204。
5. GET → 200、更新した属性の一致。
6. PUT（ID 不一致）→ 400、元の `message` / `detail`。
7. 壊れた JSON の POST → 400。
8. `page=invalid` → 400。
9. DELETE → 204。
10. 削除後 GET → 404、元の `message` / `detail`。
11. XML POST → 201。
12. XML GET → 200、JAXB による値の往復。
13. XML で作成したリソースの DELETE → 204。

確認用に作成したホテルはすべて削除しています。アンデプロイ時に HTTP Listener と内部ポートが閉じ、Java 8 子プロセスも終了することを確認しました。試験用 Mule は終了しており、既存の 8090 / 8091 の Spring Boot サーバーには手を加えていません。

最終ビルド後にも JDK 8 子プロセス方式で起動し、GET 200 とアンデプロイを確認しました。一時 JAR 削除の遅延対応後は、Bean の close 失敗警告がないことを確認しています。

## 主な互換性対応

- 元の JAR と依存 JAR を Mule の Spring / コネクターから隔離。
- JDK 17 用の JAXB 実装 / Activation 追加。元の Spring / Hibernate / H2 は保持。
- Mule が JVM 全体の URL handler factory を既に持つため、アダプター側で組み込み Tomcat の二重登録を停止。
- Mule からは `payload.^raw` をバイナリーとして渡し、JSON / XML の入力変換と壊れた入力の判定を既存 Spring MVC に委譲。

**同一 JVM の成功は、開発環境限定の JPMS 検証スキップを伴う PoC の結果です。標準設定での同一 JVM 移行や本番サポートを確認した結果ではありません。**
