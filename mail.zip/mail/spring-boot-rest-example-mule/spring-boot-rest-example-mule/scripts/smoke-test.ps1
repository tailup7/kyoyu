param(
    [string]$BaseUrl = 'http://localhost:8081',
    [hashtable]$Headers = @{}
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Net.Http
$taskHandler = New-Object System.Net.Http.HttpClientHandler
$taskHandler.AllowAutoRedirect = $false
$taskClient = New-Object System.Net.Http.HttpClient($taskHandler)
$taskClient.Timeout = [TimeSpan]::FromSeconds(60)
foreach ($taskKey in $Headers.Keys) { $taskClient.DefaultRequestHeaders.Add($taskKey, [string]$Headers[$taskKey]) }
$taskRoot = $BaseUrl.TrimEnd('/') + '/example/v1/hotels'
$taskCreated = New-Object 'System.Collections.Generic.List[string]'
$taskChecks = 0
function Send-Request([string]$Method, [string]$Url, [int]$Expected, [string]$Body, [string]$Type = 'application/json') {
    $taskRequest = New-Object System.Net.Http.HttpRequestMessage
    $taskRequest.Method = New-Object System.Net.Http.HttpMethod($Method)
    $taskRequest.RequestUri = [uri]$Url
    $taskRequest.Headers.Accept.ParseAdd($Type)
    if ($null -ne $Body -and $Body -ne '') {
        $taskRequest.Content = New-Object System.Net.Http.StringContent($Body, [Text.Encoding]::UTF8, $Type)
    }
    try {
        $taskResponse = $taskClient.SendAsync($taskRequest).GetAwaiter().GetResult()
        try {
            $taskText = $taskResponse.Content.ReadAsStringAsync().GetAwaiter().GetResult()
            if ([int]$taskResponse.StatusCode -ne $Expected) {
                throw "$Method $Url expected $Expected, got $([int]$taskResponse.StatusCode): $taskText"
            }
            $script:taskChecks++
            Write-Host "PASS $Method $Url -> $Expected"
            return @{ Body = $taskText; Location = [string]$taskResponse.Headers.Location }
        } finally { $taskResponse.Dispose() }
    } finally { $taskRequest.Dispose() }
}
try {
    $taskName = 'Mule migration ' + [guid]::NewGuid().ToString('N')
    $taskJson = @{name=$taskName; city='Tokyo'; description='Java 8 on Mule / JDK 17'; rating=3} | ConvertTo-Json -Compress
    $taskCreate = Send-Request 'POST' $taskRoot 201 $taskJson
    $taskLocation = $taskCreate.Location
    if (-not $taskLocation.StartsWith($taskRoot + '/')) { throw "Incorrect public Location: $taskLocation" }
    $taskCreated.Add($taskLocation)
    $taskHotel = (Send-Request 'GET' $taskLocation 200).Body | ConvertFrom-Json
    if ($taskHotel.name -ne $taskName) { throw 'Created hotel differs from request.' }
    $taskPage = (Send-Request 'GET' ($taskRoot + '?page=0&size=1') 200).Body | ConvertFrom-Json
    if ($taskPage.size -ne 1 -or $taskPage.number -ne 0) { throw 'Pagination query parameters were not preserved.' }
    $taskUpdate = @{id=$taskHotel.id; name=$taskName; city='Osaka'; description='updated'; rating=4} | ConvertTo-Json -Compress
    $null = Send-Request 'PUT' $taskLocation 204 $taskUpdate
    $taskUpdated = (Send-Request 'GET' $taskLocation 200).Body | ConvertFrom-Json
    if ($taskUpdated.city -ne 'Osaka' -or $taskUpdated.rating -ne 4) { throw 'Update was not persisted.' }
    $taskMismatch = @{id=0; name='mismatch'; rating=1} | ConvertTo-Json -Compress
    $taskBadId = (Send-Request 'PUT' $taskLocation 400 $taskMismatch).Body | ConvertFrom-Json
    if ($taskBadId.message -ne "ID doesn't match!" -or $taskBadId.detail -ne 'You messed up.') { throw 'Original 400 error mapping changed.' }
    $null = Send-Request 'POST' $taskRoot 400 '{broken'
    $null = Send-Request 'GET' ($taskRoot + '?page=invalid') 400
    $null = Send-Request 'DELETE' $taskLocation 204
    $taskCreated.Remove($taskLocation) | Out-Null
    $taskMissing = (Send-Request 'GET' $taskLocation 404).Body | ConvertFrom-Json
    if ($taskMissing.message -ne 'resource not found' -or $taskMissing.detail -ne "Sorry I couldn't find it.") { throw 'Original 404 error mapping changed.' }
    $taskXml = '<hotel><name>Mule XML</name><description>JAXB on Java 17</description><city>Kyoto</city><rating>2</rating></hotel>'
    $taskXmlCreate = Send-Request 'POST' $taskRoot 201 $taskXml 'application/xml'
    $taskCreated.Add($taskXmlCreate.Location)
    [xml]$taskXmlHotel = (Send-Request 'GET' $taskXmlCreate.Location 200 $null 'application/xml').Body
    if ($taskXmlHotel.hotel.city -ne 'Kyoto') { throw 'XML round trip failed.' }
    $null = Send-Request 'DELETE' $taskXmlCreate.Location 204
    $taskCreated.Remove($taskXmlCreate.Location) | Out-Null
    Write-Host "$taskChecks HTTP checks passed. JSON/XML CRUD, pagination, Location, 400 and 404 verified."
} finally {
    foreach ($taskUrl in $taskCreated) {
        try { $null = Send-Request 'DELETE' $taskUrl 204 } catch { Write-Warning "Cleanup failed: $taskUrl" }
    }
    $taskClient.Dispose()
    $taskHandler.Dispose()
}
