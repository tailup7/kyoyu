param(
    [Parameter(Mandatory = $true)][string]$MuleHome,
    [Parameter(Mandatory = $true)][string]$Java17Home,
    [string]$Java8Home,
    [switch]$LegacyJava17Experiment,
    [ValidateRange(1024, 65535)][int]$HttpPort = 8081,
    [switch]$ApiManager
)
$ErrorActionPreference = 'Stop'
if ($LegacyJava17Experiment -and $Java8Home) { throw 'Choose LegacyJava17Experiment or Java8Home.' }
if (-not $LegacyJava17Experiment -and -not $Java8Home) {
    throw 'Specify Java8Home for Java 8 process mode, or LegacyJava17Experiment for the development-only same-JVM trial.'
}
$taskProject = Split-Path -Parent $PSScriptRoot
$taskBase = Join-Path $taskProject 'target/runtime-base'
if ($HttpPort -ne 8081) { $taskBase = Join-Path $taskProject "target/runtime-base-$HttpPort" }
$taskArtifact = Join-Path $taskProject 'target/spring-boot-rest-example-mule-1.0.0-SNAPSHOT-mule-application.jar'
$taskJava = Join-Path $Java17Home 'bin/java.exe'
$taskWrapper = Join-Path $MuleHome 'lib/boot/tanuki/exec/wrapper-windows-x86-64.exe'
$taskParser = Join-Path $MuleHome 'lib/launcher/mule-wrapper-additional-parameters-parser.jar'
foreach ($taskRequired in @($taskArtifact, $taskJava, $taskWrapper, $taskParser)) {
    if (-not (Test-Path -LiteralPath $taskRequired)) { throw "Missing: $taskRequired" }
}
if ($ApiManager -and (-not $env:ANYPOINT_PLATFORM_CLIENT_ID -or -not $env:ANYPOINT_PLATFORM_CLIENT_SECRET)) {
    throw 'Set ANYPOINT_PLATFORM_CLIENT_ID and ANYPOINT_PLATFORM_CLIENT_SECRET to environment credentials first.'
}
foreach ($taskName in @('apps', 'domains', 'logs', 'conf')) {
    New-Item -ItemType Directory -Path (Join-Path $taskBase $taskName) -Force | Out-Null
}
# Mule discovers services relative to MULE_BASE. Robocopy supports their long paths.
& robocopy (Join-Path $MuleHome 'services') (Join-Path $taskBase 'services') /E /NFL /NDL /NJH /NJS /NP | Out-Null
if ($LASTEXITCODE -ge 8) { throw 'Could not copy Mule runtime services.' }
Copy-Item -Path (Join-Path $MuleHome 'conf/*') -Destination (Join-Path $taskBase 'conf') -Force
Copy-Item -LiteralPath $taskArtifact -Destination (Join-Path $taskBase 'apps') -Force
$taskConf = Join-Path $taskBase 'conf/wrapper.conf'
$taskOptions = @("-M-Dhttp.port=$HttpPort", '-M-XX:MaxMetaspaceSize=512m')
if ($LegacyJava17Experiment) {
    Write-Warning 'Development experiment only: old Spring needs a JVM opening rejected by standard Mule. This disables module-tweaking validation and is outside normal Mule support.'
    $taskOptions += @('-M--add-opens=java.base/java.lang=ALL-UNNAMED', '-M-Dmule.module.tweaking.validation.skip=true')
} else {
    $taskOptions += @('-M-Dlegacy.mode=java8-process', "-M-Dlegacy.java8.home=$Java8Home")
}
if ($ApiManager) {
    $taskOptions += @("-M-Danypoint.platform.client_id=$env:ANYPOINT_PLATFORM_CLIENT_ID",
        "-M-Danypoint.platform.client_secret=$env:ANYPOINT_PLATFORM_CLIENT_SECRET")
}
$taskOldJava = $env:JAVA_HOME
$taskOldMule = $env:MULE_HOME
$taskOldBase = $env:MULE_BASE
$env:JAVA_HOME = $Java17Home
$env:MULE_HOME = $MuleHome
$env:MULE_BASE = $taskBase
Push-Location $taskProject
try {
    # Use the distribution's launcher with a private configuration directory.
    # The shared Studio/Code Builder runtime installation is never modified.
    & $taskJava "-Dmule.home=$MuleHome" '-Dmule.wrapper.stripquotes.supported=false' -jar $taskParser $taskConf 'unused-jpda-options' @taskOptions
    if ($LASTEXITCODE -ne 0) { throw 'Mule launcher configuration failed.' }
    Write-Host "MULE_BASE: $taskBase"
    Write-Host "Hotel API: http://localhost:$HttpPort/example/v1/hotels"
    & $taskWrapper '-c' $taskConf "set.MULE_HOME=$MuleHome" "set.MULE_BASE=$taskBase" "set.JAVA_HOME=$Java17Home" "wrapper.working.dir=$taskProject"
    if ($LASTEXITCODE -ne 0) { throw "Mule exited with code $LASTEXITCODE" }
} finally {
    Pop-Location
    $env:JAVA_HOME = $taskOldJava
    $env:MULE_HOME = $taskOldMule
    $env:MULE_BASE = $taskOldBase
}
