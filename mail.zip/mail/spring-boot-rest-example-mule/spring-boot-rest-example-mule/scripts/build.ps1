param(
    [Parameter(Mandatory = $true)][string]$Java8Home,
    [Parameter(Mandatory = $true)][string]$Java17Home,
    [string]$ApiId,
    [switch]$SkipLegacyTests
)
$ErrorActionPreference = 'Stop'
$taskProject = Split-Path -Parent $PSScriptRoot
$taskOldJava = $env:JAVA_HOME
$taskOldPath = $env:PATH
foreach ($taskJdk in @($Java8Home, $Java17Home)) {
    if (-not (Test-Path -LiteralPath (Join-Path $taskJdk 'bin/java.exe'))) {
        throw "JDK not found: $taskJdk"
    }
}
if ($ApiId -and $ApiId -notmatch '^[1-9][0-9]*$') { throw 'ApiId must be an API instance ID (positive integer).' }
Push-Location $taskProject
try {
    # Build the original sources with the actual Java 8 compiler. Only the Mule tree receives outputs.
    $env:JAVA_HOME = $Java8Home
    $env:PATH = "$Java8Home\bin;$taskOldPath"
    $taskLegacyArguments = @('-B', '-ntp', '-f', 'legacy-java/pom.xml', 'clean', 'package', '-Pjava17-compat')
    if ($SkipLegacyTests) { $taskLegacyArguments += '-DskipTests' }
    & mvn @taskLegacyArguments
    if ($LASTEXITCODE -ne 0) { throw 'Java 8 legacy build failed.' }
    $env:JAVA_HOME = $Java17Home
    $env:PATH = "$Java17Home\bin;$taskOldPath"
    # Code Builder may retain open handles in its generated model cache on Windows.
    # Rename only this project's disposable cache; retain it while the IDE holds it.
    $taskCache = [IO.Path]::GetFullPath((Join-Path $taskProject '.tooling-project'))
    $taskCacheBackup = [IO.Path]::GetFullPath((Join-Path $taskProject ('.tooling-cache-' + [guid]::NewGuid().ToString('N'))))
    if (-not $taskCache.StartsWith($taskProject + '\', [StringComparison]::OrdinalIgnoreCase) -or
        -not $taskCacheBackup.StartsWith($taskProject + '\', [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Cache paths must stay inside the Mule project.'
    }
    if (Test-Path -LiteralPath $taskCache) { Move-Item -LiteralPath $taskCache -Destination $taskCacheBackup }
    $taskMuleArguments = @('-B', '-ntp', 'clean', 'package')
    if ($ApiId) { $taskMuleArguments += @('-Papi-manager', "-Dapi.id=$ApiId") }
    & mvn @taskMuleArguments
    if ($LASTEXITCODE -ne 0) { throw 'Mule build failed.' }
    Write-Host "Built: $taskProject\target\spring-boot-rest-example-mule-1.0.0-SNAPSHOT-mule-application.jar"
    if (-not $ApiId) { Write-Host 'Local verification build: API Manager is disabled.' }
} finally {
    Pop-Location
    $env:JAVA_HOME = $taskOldJava
    $env:PATH = $taskOldPath
}
