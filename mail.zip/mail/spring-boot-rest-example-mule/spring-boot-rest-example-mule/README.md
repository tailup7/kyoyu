# Spring Boot 1.5 / Java 8 → Mule 4.13.0 移行検証

元プロジェクト `../../spring-boot-rest-example` の Java ソースを直接参照して、Java 8 で通常の JAR を作成します。Controller、Service、Repository、Entity、例外ハンドラー、AOP は書き換えません。変更・生成物はこの Mule プロジェクトに置きます。

対象は既存の `pom.xml` / `mule-artifact.json` に合わせて **Mule 4.13.0 / JDK 17** としました。依頼中に併記された 4.12 は、同一の検証結果とは扱っていません。

## 結論と実行方式

**Java 8 のクラスファイル自体は JDK 17 で読み込めますが、元の依存ライブラリー構成のまま、標準設定の Mule 4.13.0 の同一 JVM で起動することはできません。** Spring 4.3.13 の CGLIB が `ClassLoader.defineClass` にリフレクションでアクセスして失敗します。単独の JDK 17 では `--add-opens=java.base/java.lang=ALL-UNNAMED` で起動できますが、Mule はその追加オプションを標準設定で拒否します。

そこで二つの実行方式を用意しました。

| 方式 | 実行する JVM | 用途 | 既存Javaアプリのコード修正 |
| --- | --- | --- | --- |
| `-LegacyJava17Experiment` | Mule と同じ JDK 17 JVM | 元の Java 8 JAR を Java Module から動かす試験。`--add-opens` と開発限定の `mule.module.tweaking.validation.skip=true` が必要。通常の Mule サポート対象となる本番構成ではありません。 | 全く行わない |
| `-Java8Home <path>` | Mule は JDK 17、元アプリは JDK 8 子プロセス | 元の依存ライブラリーを保ち、Mule の JPMS 検証を変更せず動かす代替方式。同一 JVM への移植ではありません。サーバーにも JDK 8 の設置が必要です。 | 全く行わない |

Spring 全体や `spring-core` だけを 5.3 に変更する案も確認しましたが、Boot 1.5 とのバイナリー互換性エラーが出るため採用していません。最終構成では元の Spring / Hibernate / H2 のバージョンを保持し、JDK 17 から除去された JAXB 実装と Activation のみを追加しています。

クライアントからの経路は、どちらも以下のとおりです。API Manager はポリシーを配布する管理側であり、リクエストは Mule に直接送ります。

```text
Client
  → Mule HTTP Listener :8081（API Manager のポリシーを適用）
  → Java Module / LegacyHotelBridge
  → 127.0.0.1:自動割り当てポート
  → 元の Spring MVC / HotelController / HotelService / JPA / H2
```

同一 JVM 方式では、元アプリと依存 JAR を専用 `URLClassLoader` に隔離します。Mule 側の Spring と混在させません。Java Module は業務処理を再実装せず、元の HTTP リクエストを既存 Controller に渡します。クエリ文字列・本文・業務エラーのステータスを引き継ぎ、作成時の `Location` だけを公開側 URL に戻します。Mule アンデプロイ時には Spring Context または Java 8 子プロセスを閉じます。

Windows で一時 JAR がロックされている場合、ファイル削除は Mule JVM の終了時に遅延します。ビルドスクリプトは Code Builder のロック済みモデルキャッシュを `.tooling-cache-*` に退避します。これらは生成キャッシュであり、IDE を閉じれば削除できます。

## ファイル

| ファイル | 内容 |
| --- | --- |
| `legacy-java/pom.xml` | 元ソースを Java 8 JAR にする独立ビルド。`raw-java8` は元の依存構成、`java17-compat` は JAXB / Activation 追加。元のテストも参照。 |
| `src/main/java/com/tailup/migration/LegacyHotelBridge.java` | JAR の隔離、起動・停止、HTTP 転送。 |
| `src/main/mule/spring-boot-rest-example-mule.xml` | 単一の HTTP Listener と Java Module 呼び出し。 |
| `src/main/resources/legacy-beans.xml` | Bridge の起動・終了を Mule のライフサイクルに接続。 |
| `config/api-manager-*.xml` | API Manager 有効／無効のテンプレート。 |
| `scripts/build.ps1` | JDK 8 で既存コードをビルド後、JDK 17 で Mule をビルド。 |
| `scripts/run-local.ps1` | 独立した `target/runtime-base` で Mule を起動。共用の Runtime 配布物の設定は変更しない。 |
| `scripts/smoke-test.ps1` | JSON / XML、CRUD、ページング、Location、400 / 404 を HTTP で検証。作成したホテルは削除。 |

`src/main/mule/api-manager.xml` は Maven の `initialize` でテンプレートから生成します。手で編集しないでください。通常ビルドは API Manager 無効、`-Papi-manager -Dapi.id=...` は有効になります。Maven に渡した API ID はパッケージ内の `api-instance.properties` に入り、実行時の `-Dapi.id=...` で上書きもできます。

## 1. ビルド

PowerShell で、この README のある Mule プロジェクトをカレントディレクトリーにします。以下はこの PC で確認したパスです。

```powershell
Set-Location D:\git\tailup7\mulesoft-migration\spring-boot-rest-example-mule\spring-boot-rest-example-mule

$jdk8 = 'C:\Program Files\Java\jdk-8'
$jdk17 = "$env:USERPROFILE\AnypointCodeBuilder\java\jdk-17.0.20.1+1"
$mule = "$env:USERPROFILE\.vscode\extensions\salesforce.mule-dx-runtime-1.4.0-win32-x64\build\runtime\mule-enterprise-standalone-4.13.0"

.\scripts\build.ps1 -Java8Home $jdk8 -Java17Home $jdk17
```

生成物:

```text
legacy-java/target/legacy-hotel-0.5.0.jar
legacy-java/target/runtime-libs/*.jar
target/spring-boot-rest-example-mule-1.0.0-SNAPSHOT-mule-application.jar
```

既存 Controller テスト 2 件もこのビルドで実行します。Java クラスのメジャーバージョンは 52（Java 8）です。元アプリの WAR をそのまま依存にする方式ではなく、クラスをルートに含む通常の JAR と依存 JAR を Mule パッケージの `legacy/` に格納します。

## 2. 同一 JVM / JDK 17 の試験

**開発環境限定です。** 次のスイッチは、Mule が通常拒否する追加 `--add-opens` を使用するため、モジュール変更の検証も無効にします。本番の推奨設定として採用しないでください。

```powershell
.\scripts\run-local.ps1 -MuleHome $mule -Java17Home $jdk17 -LegacyJava17Experiment
```

起動後、別の PowerShell で検証します。

```powershell
Set-Location D:\git\tailup7\mulesoft-migration\spring-boot-rest-example-mule\spring-boot-rest-example-mule
.\scripts\smoke-test.ps1
```

元アプリを 8090 / 8091 で起動していても、Mule 側は 8081 とループバックの別ポートを使用します。検証した Mule は Ctrl+C で停止します。**再ビルド時は先に停止してください。** 起動中に `mvn clean` を実行すると Windows の JAR ファイルロックで削除できません。

## 3. JDK 8 子プロセスによる代替方式

Mule は JDK 17 のまま、元の Java 8 JAR のために別 JVM を起動します。Mule の `--add-opens` 追加や検証スキップは使用しません。

```powershell
.\scripts\run-local.ps1 -MuleHome $mule -Java17Home $jdk17 -Java8Home $jdk8
```

別ターミナルで同じ `scripts/smoke-test.ps1` を実行します。デプロイ先で同方式を選ぶ場合は、サーバーに JDK 8 を設置して以下を Mule の JVM システムプロパティに設定してください。

```properties
legacy.mode=java8-process
legacy.java8.home=C:/Program Files/Java/jdk-8
```

JDK 8 は Mule の実行用 `JAVA_HOME` に設定しません。Mule 自体は必ず JDK 17 で起動します。これは Windows のスタンドアロン Mule サーバー用の実装です。Java 8 を追加できない実行基盤には、この方式をそのまま適用できません。

## 4. API Manager と接続

ローカル確認ビルドにはポリシーがありません。API Manager 管理用パッケージを別途作成し、正しい環境の認証情報で Mule を起動します。

1. Anypoint Platform の対象 Business Group / Environment を選択し、API Manager で Mule Gateway 用の API インスタンスを作成します。HTTP API として管理するか、元アプリの Swagger 仕様を Exchange に登録して使用できます。
2. 既存 Mule アプリを実装として管理する **Basic Endpoint / 自己管理のエンドポイント** を選び、Mule 4 以降を対象にします。自動生成プロキシの別デプロイは不要です。
3. Implementation URI に、クライアントから接続できる Mule の URL（例: `http://<server>:8081`）を設定します。ホテル API は `/example/v1/hotels`、API の仕様でベースパスを指定する場合もこのパスに合わせます。
4. **API Instance ID（数値）** を控えます。Exchange Asset ID や API 名ではありません。
5. Access Management から、同じ Environment の Client ID / Client Secret を取得します。これは API を呼ぶ利用者の Client ID / Secret とは別です。
6. Mule を停止してから管理用に再ビルドします。

```powershell
.\scripts\build.ps1 -Java8Home $jdk8 -Java17Home $jdk17 -ApiId '実際の数値APIインスタンスID'
```

起動前に環境認証情報を設定し、方式を選んで起動します。以下の値は実際の値に置き換えてください。

```powershell
$env:ANYPOINT_PLATFORM_CLIENT_ID = '<environment-client-id>'
$env:ANYPOINT_PLATFORM_CLIENT_SECRET = '<environment-client-secret>'

# JPMS 検証を変更しない JDK 8 子プロセス方式
.\scripts\run-local.ps1 -MuleHome $mule -Java17Home $jdk17 -Java8Home $jdk8 -ApiManager

# 同一 JVM の開発限定試験を選ぶ場合
# .\scripts\run-local.ps1 -MuleHome $mule -Java17Home $jdk17 -LegacyJava17Experiment -ApiManager
```

スタンドアロンの本来の Mule サーバーに配備する場合は、生成した `*-mule-application.jar` をそのサーバーの `apps` に配置し、`wrapper.conf` などで `anypoint.platform.client_id` と `anypoint.platform.client_secret` を設定します。連番の重複を避けてください。Mule の実行ユーザーに JDK 8 を実行する権限も必要です。EU 等のコントロールプレーンでは、公式ドキュメントに従って base URI / analytics URI も合わせてください。

ローカル起動スクリプトは認証情報を `target/runtime-base/conf/wrapper-additional.conf` に渡します。生成された設定ファイルを共有しないでください。

### 管理状態とポリシーの確認

1. API Manager で API が Active / 接続済みとなり、Mule のログに Autodiscovery の認証エラーがないことを確認します。
2. Client ID Enforcement ポリシーを適用し、API を利用するクライアントアプリを作成して契約を承認します。
3. クライアント資格情報なしの要求がポリシーにより拒否されることを確認します。ステータスは適用したポリシー設定に従います。
4. 利用者用の資格情報付きで CRUD 検証します（Environment の資格情報はここに使いません）。以下はポリシーが `client_id` / `client_secret` HTTP ヘッダーを見る場合です。

```powershell
.\scripts\smoke-test.ps1 -BaseUrl 'http://localhost:8081' -Headers @{
    client_id = '<consumer-client-id>'
    client_secret = '<consumer-client-secret>'
}
```

5. 必要に応じて Rate Limiting を適用し、設定値を超えた要求が拒否されること、および Analytics に要求が反映されることを確認します。

`flowRef="hotel-api-main"` は HTTP Listener のある入口フローに設定しています。CRUD の一部だけを別の未管理 Listener に逃がす構成ではありません。

**API Manager 上での登録・契約・ポリシー適用は、対象アカウントの ID / 認証情報が未提供のため未実施です。XML を作成したことだけで API Manager 接続済みとは判定しません。**

## 制約と確認点

- H2 は元と同じインメモリー DB です。起動中の元アプリのデータは自動で移りません。Mule 再起動・アンデプロイでデータが失われます。
- ホテル API と Swagger 等の元のアプリ側パスを Mule の入口から転送します。元の管理ポート 8091 の Actuator は `management.port=-1` で公開を止めています。管理 API の公開・監視の移行は別途設計が必要です。
- `PUT` の本文には URL と同じ `id` が必要です。元の実装どおり、不一致なら 400 です。
- リクエストとレスポンスはメモリーに読み込みます。このサンプルの小さな JSON / XML を対象とし、大容量ストリーミングや任意の Web アプリケーションの完全なリバースプロキシを目的とした実装ではありません。
- JDK 8 子プロセス方式で使う JDK 8 と既存ライブラリーについて、運用環境での保守・サポートを確認してください。同一 JVM の検証成功も、Boot 1.5 の JDK 17 サポートを意味しません。
- 4.12 に切り替える場合は `pom.xml` の `app.runtime` と `mule-artifact.json` の `minMuleVersion` を両方変更し、4.12 の配布物で同じ試験を再実行してください。

ログは `target/runtime-base/logs` に出ます。Java 8 子プロセスの Spring ログは `legacy-hotel-java8.log`、Mule アプリのログは `spring-boot-rest-example-mule.log`、Mule 自体のログは `mule_ee.log` です。

`-HttpPort 8082` のようにポートを変更した場合は `target/runtime-base-8082` を使います。今回の実行結果は [VERIFICATION.md](VERIFICATION.md) を参照してください。

## 参照した公式資料

- [Mule の Java サポート・追加 JPMS オプションの制約](https://docs.mulesoft.com/general/java-support)
- [API Autodiscovery の設定](https://docs.mulesoft.com/mule-gateway/mule-gateway-config-autodiscovery-mule4)
- [環境・組織の資格情報](https://docs.mulesoft.com/mule-gateway/mule-gateway-org-credentials-mule4)
- [Java Module のメソッド呼び出し](https://docs.mulesoft.com/java-module/latest/java-invoke-method)
- [Mule のクラスローダー分離](https://docs.mulesoft.com/mule-runtime/latest/about-classloading-isolation)
