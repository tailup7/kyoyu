package com.tailup.migration;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Hosts the unchanged Spring application in the Mule JVM, with isolated libraries. */
public final class LegacyHotelBridge implements AutoCloseable {
    private static final Set<String> HOP_HEADERS = new HashSet<String>(Arrays.asList(
            "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
            "te", "trailer", "transfer-encoding", "upgrade", "host", "content-length"));
    private URLClassLoader loader;
    private Object context;
    private Process legacyProcess;
    private Path directory;
    private String internalOrigin;
    private int timeoutMillis = 30000;

    public void setTimeoutMillis(int timeoutMillis) {
        this.timeoutMillis = timeoutMillis;
    }

    /** Called by the Mule Spring module at deployment; close() runs on undeployment. */
    public synchronized void start() throws Exception {
        if (context != null || legacyProcess != null) {
            return;
        }
        ClassLoader previous = Thread.currentThread().getContextClassLoader();
        try {
            Path work = java.nio.file.Paths.get(System.getProperty("mule.base", System.getProperty("java.io.tmpdir")), ".mule");
            Files.createDirectories(work);
            directory = Files.createTempDirectory(work, "legacy-hotel-");
            List<URL> urls = new ArrayList<URL>();
            try (InputStream index = getClass().getResourceAsStream("/legacy/classpath.txt")) {
                if (index == null) {
                    throw new IllegalStateException("Legacy JARs are missing. Run scripts/build.ps1 first.");
                }
                String names = new String(readAll(index), "UTF-8");
                for (String name : names.split("\\r?\\n")) {
                    if (name.trim().isEmpty()) {
                        continue;
                    }
                    if (!name.matches("[A-Za-z0-9_.-]+\\.jar")) {
                        throw new IllegalStateException("Invalid legacy classpath entry: " + name);
                    }
                    Path jar = directory.resolve(name);
                    try (InputStream source = getClass().getResourceAsStream("/legacy/" + name)) {
                        if (source == null) {
                            throw new IllegalStateException("Missing legacy dependency: " + name);
                        }
                        Files.copy(source, jar);
                    }
                    urls.add(jar.toUri().toURL());
                }
            }
            if ("java8-process".equals(System.getProperty("legacy.mode"))) {
                startJava8Process();
                return;
            }
            // On JDK 17 this parent is the platform class loader: no Mule/Spring classes.
            loader = new URLClassLoader(urls.toArray(new URL[urls.size()]),
                    ClassLoader.getSystemClassLoader().getParent());
            Thread.currentThread().setContextClassLoader(loader);
            // Mule already owns the JVM-wide URLStreamHandlerFactory. Tomcat must not replace it.
            loader.loadClass("org.apache.catalina.webresources.TomcatURLStreamHandlerFactory")
                    .getMethod("disable").invoke(null);
            Class<?> application = loader.loadClass("com.khoubyari.example.Application");
            Class<?> spring = loader.loadClass("org.springframework.boot.SpringApplication");
            Object launcher = spring.getConstructor(Object[].class)
                    .newInstance(new Object[] {new Object[] {application}});
            spring.getMethod("setRegisterShutdownHook", boolean.class).invoke(launcher, false);
            String[] arguments = {
                    "--server.address=127.0.0.1", "--server.port=0",
                    "--management.port=-1", "--spring.jmx.enabled=false",
                    "--spring.main.banner-mode=off"
            };
            context = spring.getMethod("run", String[].class).invoke(launcher, (Object) arguments);
            Class<?> webContext = loader.loadClass(
                    "org.springframework.boot.context.embedded.EmbeddedWebApplicationContext");
            Object container = webContext.getMethod("getEmbeddedServletContainer").invoke(context);
            int port = ((Number) loader.loadClass(
                    "org.springframework.boot.context.embedded.EmbeddedServletContainer")
                    .getMethod("getPort").invoke(container)).intValue();
            internalOrigin = "http://127.0.0.1:" + port;
        } catch (Exception ex) {
            try {
                close();
            } catch (Exception cleanup) {
                ex.addSuppressed(cleanup);
            }
            Throwable cause = ex instanceof InvocationTargetException
                    ? ((InvocationTargetException) ex).getTargetException() : ex;
            throw new IllegalStateException("Legacy Spring Boot startup failed on Java "
                    + System.getProperty("java.version")
                    + ". See README.md for the Java 17 experiment or java8-process mode.", cause);
        } finally {
            Thread.currentThread().setContextClassLoader(previous);
        }
    }

    /** Transport only: all routing, binding, CRUD, AOP and exception mapping stay in Spring. */
    public Map<String, Object> handle(String method, String requestUri, String publicOrigin,
                                      Map<String, Object> headers, byte[] body) throws Exception {
        if (context == null && legacyProcess == null) {
            throw new IllegalStateException("The legacy application has not started.");
        }
        URI uri = URI.create(requestUri);
        if (uri.isAbsolute() || uri.getRawAuthority() != null || !requestUri.startsWith("/")) {
            throw new IllegalArgumentException("Expected an origin-form HTTP request URI");
        }
        HttpURLConnection connection = (HttpURLConnection) new URL(internalOrigin + requestUri).openConnection();
        connection.setRequestMethod(method);
        connection.setInstanceFollowRedirects(false);
        connection.setConnectTimeout(timeoutMillis);
        connection.setReadTimeout(timeoutMillis);
        Set<String> excluded = new HashSet<String>(HOP_HEADERS);
        for (Map.Entry<String, Object> header : headers.entrySet()) {
            if ("connection".equalsIgnoreCase(header.getKey())) {
                for (String token : String.valueOf(header.getValue()).split(",")) {
                    excluded.add(token.trim().toLowerCase(Locale.ROOT));
                }
            }
        }
        try {
            for (Map.Entry<String, Object> header : headers.entrySet()) {
                if (!excluded.contains(header.getKey().toLowerCase(Locale.ROOT))) {
                    connection.setRequestProperty(header.getKey(), String.valueOf(header.getValue()));
                }
            }
            if (body != null && body.length > 0) {
                connection.setDoOutput(true);
                connection.setFixedLengthStreamingMode(body.length);
                try (OutputStream output = connection.getOutputStream()) {
                    output.write(body);
                }
            }
            int status = connection.getResponseCode();
            Map<String, String> responseHeaders = new LinkedHashMap<String, String>();
            Set<String> responseExcluded = new HashSet<String>(HOP_HEADERS);
            String responseConnection = connection.getHeaderField("Connection");
            if (responseConnection != null) {
                for (String token : responseConnection.split(",")) {
                    responseExcluded.add(token.trim().toLowerCase(Locale.ROOT));
                }
            }
            for (Map.Entry<String, List<String>> header : connection.getHeaderFields().entrySet()) {
                String name = header.getKey();
                if (name == null || responseExcluded.contains(name.toLowerCase(Locale.ROOT))) {
                    continue;
                }
                List<String> values = new ArrayList<String>(header.getValue());
                Collections.reverse(values);
                String value = String.join(", ", values);
                if ("location".equalsIgnoreCase(name) && value.startsWith(internalOrigin + "/")) {
                    value = publicOrigin + value.substring(internalOrigin.length());
                }
                responseHeaders.put(name, value);
            }
            byte[] responseBody;
            try (InputStream input = status >= 400 ? connection.getErrorStream() : connection.getInputStream()) {
                responseBody = input == null ? new byte[0] : readAll(input);
            }
            Map<String, Object> result = new LinkedHashMap<String, Object>();
            result.put("status", status);
            result.put("headers", responseHeaders);
            result.put("body", responseBody);
            return result;
        } finally {
            connection.disconnect();
        }
    }

    @Override
    public synchronized void close() throws Exception {
        ClassLoader previous = Thread.currentThread().getContextClassLoader();
        Exception failure = null;
        try {
            if (legacyProcess != null) {
                legacyProcess.destroy();
                if (!legacyProcess.waitFor(15, java.util.concurrent.TimeUnit.SECONDS)) {
                    legacyProcess.destroyForcibly().waitFor();
                }
                legacyProcess = null;
            }
            if (loader != null) {
                Thread.currentThread().setContextClassLoader(loader);
            }
            if (context != null) {
                try {
                    loader.loadClass("org.springframework.context.ConfigurableApplicationContext")
                            .getMethod("close").invoke(context);
                } catch (Exception ex) {
                    failure = ex;
                } finally {
                    context = null;
                }
            }
            if (loader != null) {
                loader.close();
                loader = null;
            }
            if (directory != null) {
                // Register the directory first: JVM exit cleanup runs in reverse order.
                directory.toFile().deleteOnExit();
                try (java.nio.file.DirectoryStream<Path> jars = Files.newDirectoryStream(directory)) {
                    for (Path jar : jars) {
                        try {
                            Files.deleteIfExists(jar);
                        } catch (java.io.IOException lockedOnWindows) {
                            jar.toFile().deleteOnExit();
                        }
                    }
                }
                try {
                    Files.deleteIfExists(directory);
                } catch (java.nio.file.DirectoryNotEmptyException pendingExitCleanup) {
                    // Windows may retain JAR handles until the Mule JVM terminates.
                }
                directory = null;
            }
            if (failure != null) {
                throw failure;
            }
        } finally {
            Thread.currentThread().setContextClassLoader(previous);
        }
    }

    private void startJava8Process() throws Exception {
        String java8Home = System.getProperty("legacy.java8.home");
        if (java8Home == null) {
            throw new IllegalStateException("Set legacy.java8.home for java8-process mode.");
        }
        Path javaExecutable = java.nio.file.Paths.get(java8Home, "bin", "java.exe");
        if (!Files.isRegularFile(javaExecutable)) {
            throw new IllegalStateException("Java 8 executable not found: " + javaExecutable);
        }
        int port;
        try (java.net.ServerSocket reservation = new java.net.ServerSocket(
                0, 1, java.net.InetAddress.getLoopbackAddress())) {
            port = reservation.getLocalPort();
        }
        Path logs = java.nio.file.Paths.get(System.getProperty("mule.base", directory.toString()), "logs");
        Files.createDirectories(logs);
        legacyProcess = new ProcessBuilder(javaExecutable.toString(), "-cp", directory.toString() + java.io.File.separator + "*",
                "com.khoubyari.example.Application", "--server.address=127.0.0.1", "--server.port=" + port,
                "--management.port=-1", "--spring.jmx.enabled=false", "--spring.main.banner-mode=off")
                .redirectErrorStream(true).redirectOutput(logs.resolve("legacy-hotel-java8.log").toFile()).start();
        internalOrigin = "http://127.0.0.1:" + port;
        long deadline = System.nanoTime() + java.util.concurrent.TimeUnit.SECONDS.toNanos(120);
        while (System.nanoTime() < deadline) {
            if (!legacyProcess.isAlive()) {
                throw new IllegalStateException("Legacy Java process exited: " + legacyProcess.exitValue()
                        + ". See logs/legacy-hotel-java8.log");
            }
            HttpURLConnection probe = (HttpURLConnection) new URL(
                    internalOrigin + "/example/v1/hotels?page=0&size=1").openConnection();
            probe.setConnectTimeout(500);
            probe.setReadTimeout(500);
            try {
                if (probe.getResponseCode() == 200) {
                    return;
                }
            } catch (java.io.IOException notReady) {
                // Wait until the original application has finished bootstrapping.
            } finally {
                probe.disconnect();
            }
            Thread.sleep(200);
        }
        throw new IllegalStateException("Legacy startup timed out. See logs/legacy-hotel-java8.log");
    }

    private static byte[] readAll(InputStream input) throws java.io.IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int count;
        while ((count = input.read(buffer)) != -1) {
            output.write(buffer, 0, count);
        }
        return output.toByteArray();
    }
}
